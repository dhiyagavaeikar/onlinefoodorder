# from pydantic import BaseModel

# class UserAuthSessionModel(BaseModel):
#     user_role: str