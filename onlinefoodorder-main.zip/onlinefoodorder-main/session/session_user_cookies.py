
# from fastapi_sessions.frontends.implementations import SessionCookie, CookieParameters
# cookie_params = CookieParameters()

# cookie = SessionCookie(
#     cookie_name="cookie",
#     identifier="general_verifier",
#     auto_error=True,
#     secret_key="DONOTUSE",
#     cookie_params=cookie_params,
# )